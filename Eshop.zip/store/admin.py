from django.contrib import admin

# Register your models here.
from store.models import Product, Category, Customer,Order


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ['id', 'name', 'price', 'description', 'image']


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['id', 'name']


@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ['id', 'first_name',
                    'last_name', 'email', 'phone', 'password']

@admin.register(Order)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ['id', 'quantity','price','date','phone','address']
