from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, redirect
from .models.product import Product
from .models.category import Category
from .models.customer import Customer
from .models.orders import Order
from django.contrib.auth.hashers import make_password, check_password
from store.middlewares.auth import auth_middleware
from django.utils.decorators import method_decorator
# Create your views here.


def index(requset):
    cart = requset.session.get('cart')
    if not cart:
        requset.session.cart = {}
    if not cart:
        requset.session['cart'] = {}
    if requset.method == 'GET':
        products = None

        categories = Category.get_all_categories()
        categoryID = requset.GET.get('category')
        if categoryID:
            products = Product.get_all_products_by_categoryid(categoryID)
        else:
            products = Product.get_all_products()

        data = {}
        data['products'] = products
        data['categories'] = categories

        return render(requset, 'index.html', data)
    else:
        product = requset.POST.get('product')
        remove = requset.POST.get('remove')
        cart = requset.session.get('cart')
        if cart:
            quantity = cart.get(product)
            if quantity:
                if remove:
                    if quantity <= 1:
                        cart.pop(product)
                    else:
                        cart[product] = quantity-1
                else:
                    cart[product] = quantity+1
            else:
                cart[product] = 1

        else:
            cart = {}
            cart[product] = 1

        requset.session['cart'] = cart

        return redirect('index')


def signup(request):
    if request.method == 'GET':
        return render(request, 'signup.html')
    else:
        postData = request.POST
        first_name = postData.get('firstname')
        last_name = postData.get('lastname')
        email = postData.get('email')
        phone = postData.get('phone')
        password = postData.get('password')
        customer = Customer(first_name=first_name, last_name=last_name,
                            email=email, phone=phone, password=password)

        value = {

            'first_name': first_name,
            'last_name': last_name,
            'email': email,
            'phone': phone

        }

        error_msg = None

        if not first_name:
            error_msg = "First name is required..."
        elif not last_name:
            error_msg = "Last name id required!!"
        elif not email:
            error_msg = "Email is required!!"
        elif not phone:
            error_msg = "phone number is required..."
        elif not password:
            error_msg = "password is required!!"
        elif customer.isExists():
            error_msg = "Email is already exist....."

        if not error_msg:
            customer.password = make_password(customer.password)
            customer.register()
            return redirect('index')
        else:
            data = {
                'error': error_msg,
                'value': value
            }
            return render(request, 'signup.html', data)


def login(request):
    return_url = None
    if request.method == 'GET':
        login.return_url = request.GET.get('return_url')
        return render(request, 'login.html')
    else:
        email = request.POST.get('email')
        password = request.POST.get('password')
        customer = Customer.get_customer_by_email(email)
        error_msg = None
        if customer:
            flag = check_password(password, customer.password)
            if flag:
                request.session['customer'] = customer.id
                request.session['email'] = customer.email

                if return_url:
                    return HttpResponseRedirect(login.return_url)
                else:
                    login.return_url = None
                    return redirect('index')

            else:
                error_msg = "invalid email or password"
        else:
            error_msg = "invalid email or password"

        return render(request, 'login.html', {'error': error_msg})


def logout(request):
    request.session.clear()
    return redirect('login')


def cart(request):

    ids = list(request.session.get('cart').keys())
    products = Product.get_products_by_id(ids)

    return render(request, 'cart.html', {'products': products})


@auth_middleware
def check(request):
    address = request.POST.get('address')
    phone = request.POST.get('phone')
    customer = request.session.get('customer')
    cart = request.session.get('cart')
    products = Product.get_products_by_id(list(cart.keys()))

    for product in products:
        order = Order(customer=Customer(id=customer), product=product,
                      price=product.price, quantity=cart.get(str(product.id)), address=address, phone=phone)

        order.save()
    request.session['cart'] = {}
    return redirect('cart')


@auth_middleware
def order(request):

    customer = request.session.get('customer')
    oders = Order.orders_by_customer(customer)

    return render(request, 'order.html', {'oders': oders})
